=== Plugin Name ===
Contributors: freepius
Tags: learnybox, map
Requires at least: 5.6
Tested up to: 5.6
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

LearnyboxMap allows your LearnyBox members to be displayed on an interactive map and see other members there.

== Description ==

The LearnyboxMap plugin allows your LearnyBox members to add themselves on an interactive map and see other members already added.
As a WordPress admin, you can configure the plugin and the map, as well as manage the displayed members.

== Installation ==

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

== Upgrade Notice ==